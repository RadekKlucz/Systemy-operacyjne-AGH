import socket 

udp_user_2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
udp_user_2.bind(("", 20002)) 

user_1_ip = ("", 20003)

def send_char(character):
    udp_user = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_user.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    udp_user.sendto(bytes(character, 'utf-8'), user_1_ip)
    udp_user.close()


while(True):
    data, address = udp_user_2.recvfrom(20001)
    data = str(data, 'utf-8')
    if data == "quit":
        print("Program has ended")
        break
    else:
        print(data)

    character = input(">>")
    if not character:
        break
    else:
        send_char(character)