import socket 
# Utowrzenie socketa do odbioru 
udp_user_1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
# przypisanie IP I numeru portu
udp_user_1.bind(("", 20001)) 

# ip usera 2
user_2_ip = ("", 20002) 


def send_char(character):
    udp_user = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_user.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    udp_user.sendto(bytes(character, 'utf-8'), user_2_ip)
    udp_user.close()


while(True):
    # do wpisania wiadomosci
    character = input(">>")
    if not character:
        break
    else:
        send_char(character)

    data, address = udp_user_1.recvfrom(20003)
    data = str(data, 'utf-8')

    if data == "quit":
        print("Program has ended")
        break
    else:
        print(data)