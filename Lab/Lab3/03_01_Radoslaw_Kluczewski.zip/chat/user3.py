import socket 
# Utowrzenie socketa do odbioru 
udp_user_1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
# przypisanie IP I numeru portu
udp_user_1.bind(("", 20003)) 

# ip usera 1
user_1_ip = ("", 20001) 

def send_char(character):
    udp_user = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_user.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    udp_user.sendto(bytes(character, 'utf-8'), user_1_ip)
    udp_user.close()

while(True):

    data, address = udp_user_1.recvfrom(20002)
    data = str(data, 'utf-8')

    if data == "quit":
        print("Program has ended")
        break
    else:
        print(data)

     # do wpisania wiadomosci
    character = input(">>")
    if not character:
        break
    else:
        send_char(character)